# NAND_CTRL
# Add by Luomengjie

# Feature
# page size (2048+64) or (512+16)
# internal ldpc ecc(128 byte)
# ONFI 4.0 mode or Toggle mode SDR

####################
## Operation Support
####################
# Read ID(IDD)
# Erase Block
# PROGRAM PAGE
# READ PAGE
# READ Status
# Reset

